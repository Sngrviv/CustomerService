// src/pages/Automation.jsx
import React from 'react';

const SentimentAnalysis = () => {
  return (
    <div>
      <h1>Automation Page</h1>
      <p>Content for the Automation page.</p>
    </div>
  );
};

export default SentimentAnalysis; // Ensure default export exists

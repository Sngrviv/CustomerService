// src/pages/Automation.jsx
import React from 'react';

const Automation = () => {
  return (
    <div>
      <h1>Automation Page</h1>
      <p>Content for the Automation page.</p>
    </div>
  );
};

export default Automation; // Ensure default export exists

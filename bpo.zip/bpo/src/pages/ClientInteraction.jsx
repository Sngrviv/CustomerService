// src/pages/Automation.jsx
import React from 'react';

const ClientInteraction = () => {
  return (
    <div>
      <h1>Automation Page</h1>
      <p>Content for the Automation page.</p>
    </div>
  );
};

export default ClientInteraction; // Ensure default export exists

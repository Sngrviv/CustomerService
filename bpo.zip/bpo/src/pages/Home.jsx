// src/pages/Home.jsx
import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to the Dashboard</h2>
      <p>This is the home page content.</p>
    </div>
  );
};

export default Home;

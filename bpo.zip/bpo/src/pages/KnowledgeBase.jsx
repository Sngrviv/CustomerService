// src/pages/Automation.jsx
import React from 'react';

const KnowledgeBase = () => {
  return (
    <div>
      <h1>Automation Page</h1>
      <p>Content for the Automation page.</p>
    </div>
  );
};

export default KnowledgeBase; // Ensure default export exists

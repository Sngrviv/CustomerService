// src/utils/buffer.js
import { Buffer } from 'buffer';

// Make Buffer globally available
window.Buffer = Buffer;

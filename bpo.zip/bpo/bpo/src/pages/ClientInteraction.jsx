// src/pages/Automation.jsx
import React from 'react';

const ClientInteraction = () => {
  return (
    <div>
      <h1>ClientInteraction Page</h1>
      <p>Content for the Client Interaction.</p>
    </div>
  );
};

export default ClientInteraction; // Ensure default export exists

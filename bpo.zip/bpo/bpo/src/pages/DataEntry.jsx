// src/pages/Automation.jsx
import React from 'react';

const DataEntry = () => {
  return (
    <div>
      <h1>Data Entry Page</h1>
      <p>Content for the Data entry page.</p>
    </div>
  );
};

export default DataEntry; // Ensure default export exists

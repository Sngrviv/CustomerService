// src/pages/Automation.jsx
import React from 'react';

const SentimentAnalysis = () => {
  return (
    <div>
      <h1>Sentiment analysis Page</h1>
      <p>Content for the Sentiment analysis page.</p>
    </div>
  );
};

export default SentimentAnalysis; // Ensure default export exists
